import random
from pytest_check import check
from Calculator import Calculator


def test_two():
    assert Calculator.add(2, 4) == 10


def test_a():
    assert Calculator.add(2, 4) == 6


def test_b():
    assert Calculator.mul(3, 4) == 10


def test_c():
    assert Calculator.mul(3, 4) == 11


def test_d():
    assert Calculator.mul(3, 4) == 100


def test_e():
    assert Calculator.mul(3, 4) == 12


def test_f():
    assert Calculator.div(3, 0) == 0


def test_g():
    assert Calculator.sub(399, 199) == 200


def test_h():
    assert Calculator.sub(399, 199) == 2003


def test_i():
    assert Calculator.sub(399, 199) == 2353


def test_j():
    assert Calculator.sub(333, 199) == 200


def test_k():
    assert Calculator.sub(399, 199) == 105


def test_l():
    assert Calculator.sub(399, 199) == 399 - 199


def test_m():
    assert False


def test_n():
    assert True


def test_o():
    assert 1 == 1


def test_p():
    assert Calculator.mul(Calculator.add(3, 5), Calculator.sub(8, 7)) == 8


def test_a1():
    assert Calculator.add(2, 4) == 6


def test_b1():
    assert Calculator.mul(3, 4) == 10


def test_c1():
    assert Calculator.mul(3, 4) == 11


def test_d1():
    assert Calculator.mul(3, 4) == 100


def test_e1():
    assert Calculator.mul(3, 4) == 12


def test_f1():
    assert Calculator.div(3, 0) == 0


def test_g1():
    assert Calculator.sub(399, 199) == 200


def test_h1():
    assert Calculator.sub(399, 199) == 2003


def test_i1():
    assert Calculator.sub(399, 199) == 2353


def test_j1():
    assert Calculator.sub(333, 199) == 200


def test_k1():
    assert Calculator.sub(399, 199) == 105


def test_l1():
    assert Calculator.sub(399, 199) == 399 - 199


def test_m1():
    assert False


def test_n1():
    assert True


def test_o1():
    assert 1 == 1


def test_p1():
    assert Calculator.mul(Calculator.add(3, 5), Calculator.sub(8, 7)) == 8


def test_a2():
    assert Calculator.add(2, 4) == 6


def test_b2():
    assert Calculator.mul(3, 4) == 10


def test_c2():
    assert Calculator.mul(3, 4) == 11


def test_d2():
    assert Calculator.mul(3, 4) == 100


def test_e2():
    assert Calculator.mul(3, 4) == 12


def test_f2():
    assert Calculator.div(3, 0) == 0


def test_g2():
    assert Calculator.sub(399, 199) == 200


def test_h2():
    assert Calculator.sub(399, 199) == 2003


def test_i2():
    assert Calculator.sub(399, 199) == 2353


def test_j2():
    assert Calculator.sub(333, 199) == 200


def test_k2():
    assert Calculator.sub(399, 199) == 105


def test_l2():
    assert Calculator.sub(399, 199) == 399 - 199


def test_m2():
    assert False


def test_n2():
    assert True


def test_o2():
    assert 1 == 1


def test_p2():
    assert Calculator.mul(Calculator.add(3, 5), Calculator.sub(8, 7)) == 8


def test_a3():
    assert Calculator.add(2, 4) == 6


def test_b3():
    assert Calculator.mul(3, 4) == 10


def test_c3():
    assert Calculator.mul(3, 4) == 11


def test_d3():
    assert Calculator.mul(3, 4) == 100


def test_e3():
    assert Calculator.mul(3, 4) == 12


def test_f3():
    assert Calculator.div(3, 0) == 0


def test_g3():
    assert Calculator.sub(399, 199) == 200


def test_h3():
    assert Calculator.sub(399, 199) == 2003


def test_i3():
    assert Calculator.sub(399, 199) == 2353


def test_j3():
    assert Calculator.sub(333, 199) == 200


def test_k3():
    assert Calculator.sub(399, 199) == 105


def test_l3():
    assert Calculator.sub(399, 199) == 399 - 199


def test_m3():
    assert False


def test_n3():
    assert True


def test_o3():
    assert 1 == 1


def test_p3():
    assert Calculator.mul(Calculator.add(3, 5), Calculator.sub(8, 7)) == 8


def test_a4():
    assert Calculator.add(2, 4) == 6


def test_b4():
    assert Calculator.mul(3, 4) == 10


def test_c4():
    assert Calculator.mul(3, 4) == 11


def test_d4():
    assert Calculator.mul(3, 4) == 100


def test_e4():
    assert Calculator.mul(3, 4) == 12


def test_f4():
    assert Calculator.div(3, 0) == 0


def test_g4():
    assert Calculator.sub(399, 199) == 200


def test_h4():
    assert Calculator.sub(399, 199) == 2003


def test_i4():
    assert Calculator.sub(399, 199) == 2353


def test_j4():
    assert Calculator.sub(333, 199) == 200


def test_k4():
    assert Calculator.sub(399, 199) == 105


def test_l4():
    assert Calculator.sub(399, 199) == 399 - 199


def test_m4():
    assert False


def test_n4():
    assert True


def test_o4():
    assert 1 == 1


def test_p4():
    assert Calculator.mul(Calculator.add(3, 5), Calculator.sub(8, 7)) == 8