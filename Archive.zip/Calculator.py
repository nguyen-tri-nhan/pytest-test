class Calculator:
    @staticmethod
    def add(num1, num2):
        return num1 + num2

    @staticmethod
    def sub(num1, num2):
        return num1 - num2

    @staticmethod
    def div(num1, num2):
        return num1 / num2

    @staticmethod
    def mul(num1, num2):
        return num1 * num2
