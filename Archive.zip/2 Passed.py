def test():
    assert 1 == 1


def test2():
    assert 1 == 1
