def test():
    assert False


def test2():
    assert False