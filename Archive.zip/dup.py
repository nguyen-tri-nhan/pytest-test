def test_a():
    print("This is a test for 2 similar results in one similar failures stuff")
    print("-" * 50)
    assert 1 == 2


def test_b():
    print("This is a test for 2 similar results in one similar failures stuff")
    print("-" * 50)
    assert 1 == 2
